﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public class UpdateDocumentAttributes
    {
        public string id { get; set; }
        public string name { get; set; }
        public string original_voice_actor { get; set; }
        public string animated_debut { get; set; }
    }
}