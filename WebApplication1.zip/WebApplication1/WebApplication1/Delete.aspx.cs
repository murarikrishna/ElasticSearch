﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Delete : System.Web.UI.Page
    {
        string documentID = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            bool status;
            documentID = TextBox1.Text;

            status = CRUD.deleteDocument(documentID);

            if (status == true)
            {
                TextBox2.Text="Document Deleted Successfully";
            }
            else
            {
                TextBox2.Text = "Error Occured During Document Delete!";
            }
        }
    }
}