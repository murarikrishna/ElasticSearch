﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Search : System.Web.UI.Page
    {
        string documentID = "";
        string id = "";
        string name = "";
        string originalVoiceActor = "";
        string animatedDebut = "";

        string[] arrCharacter = new string[4];
        ListViewItem itm;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            documentID = txtSearch.Text;
            var disneyCharacter = CRUD.getDocument(documentID);
            var list = new List<Tuple<string, string, string, string>>();

            
            list.Add(disneyCharacter);

            GridView1.DataSource = list;
        }

       
        
    }
}