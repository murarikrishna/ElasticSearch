﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Create_Index : System.Web.UI.Page
    {
        string documentID = "";
        string id = "";
        string name = "";
        string originalVoiceActor = "";
        string animatedDebut = "";

        string[] arrCharacter = new string[4];
        ListViewItem itm;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            bool status;

            id = txtId.Text;
            name = txtIndex.Text;
            originalVoiceActor = txtType.Text;
            animatedDebut = txtBody.Text;

            status = CRUD.insertDocument(id, name, originalVoiceActor, animatedDebut);

            if (status == true)
            {
                txtSucess.Text= "Document Inserted/ Indexed Successfully";
            }
            else
            {
                txtSucess.Text = "Error! Occured During Document Insert/ Index!";
            }
        }
    }
}